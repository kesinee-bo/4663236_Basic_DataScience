// ===== แบบ B: JavaScript ทำนายเองในเบราว์เซอร์ด้วย onnxruntime-web (ไม่ต้องมี backend) =====
// ไฟล์ที่ต้องอยู่ในโฟลเดอร์เดียวกัน: diabetes_model.onnx, model_meta.json (ได้จาก Colab)
// ไฟล์ .onnx มีแค่ KNN ส่วนการ scale ทำในไฟล์นี้ด้วยค่าใน model_meta.json
// ต้องเปิดผ่าน web server (เช่น python -m http.server) เพราะ fetch ไฟล์จาก file:// ไม่ได้
const MODEL_URL = "diabetes_model.onnx";
const META_URL = "model_meta.json";

// ลำดับต้องตรงกับ FEATURES ตอน train (ONNX รับเป็น array ตัวเลข ไม่มีชื่อคอลัมน์)
const FEATURES = ["Pregnancies", "Glucose", "BloodPressure", "SkinThickness",
                  "Insulin", "BMI", "DiabetesPedigreeFunction", "Age"];

const PRESETS = {
  high: { Pregnancies: 6, Glucose: 148, BloodPressure: 72, SkinThickness: 35, Insulin: 125, BMI: 33.6, DiabetesPedigreeFunction: 0.627, Age: 50 },
  low:  { Pregnancies: 1, Glucose: 85,  BloodPressure: 66, SkinThickness: 29, Insulin: 125, BMI: 26.6, DiabetesPedigreeFunction: 0.351, Age: 31 },
};

const $ = (id) => document.getElementById(id);
let session = null;   // ort.InferenceSession โหลดครั้งเดียว ใช้ซ้ำได้
let meta = null;

// ---------- 1) อ่านค่าจากฟอร์ม (เหมือนแบบ A) ----------
function readForm() {
  const data = {};
  for (const name of FEATURES) {
    const input = $(name);
    const raw = input.value.trim();
    if (raw === "") throw new Error(`กรุณากรอก "${input.labels[0].firstChild.textContent.trim()}"`);
    const v = Number(raw);
    if (Number.isNaN(v) || v < Number(input.min) || v > Number(input.max)) {
      throw new Error(`ค่า ${name} ต้องอยู่ระหว่าง ${input.min}–${input.max}`);
    }
    data[name] = v;
  }
  return data;
}

// ---------- 2) scale + ทำนายด้วย ONNX ----------
async function predict(data) {
  // 1) แปลง object -> array ตัวเลข เรียงตาม FEATURES
  const raw = FEATURES.map((f) => data[f]);

  // 2) scale แบบเดียวกับ StandardScaler ใน Python: (x - mean) / scale
  //    ค่า mean/scale มาจาก model_meta.json (บันทึกไว้ตอน train)
  const { mean, scale } = meta.scaler;
  const row = raw.map((x, i) => (x - mean[i]) / scale[i]);
  const input = new ort.Tensor("float32", Float32Array.from(row), [1, FEATURES.length]);

  // 3) ทำนาย
  const out = await session.run({ input });          // ชื่อ "input" ตั้งไว้ตอน to_onnx
  const prediction = Number(out.label.data[0]);       // label เป็น int64 -> BigInt จึงต้องแปลง
  const probability = out.probabilities.data[1];      // [P(คลาส 0), P(คลาส 1)]
  return { prediction, label: meta.classes[String(prediction)], probability };
}

// ---------- 3) แสดงผล ----------
function showResult(data, out) {
  const pct = out.probability * 100;
  $("result").dataset.class = String(out.prediction);
  $("pct").innerHTML = `${pct.toFixed(1)}<small>%</small>`;
  $("label").textContent = out.label;
  $("fill").style.width = `${pct}%`;
  $("io").textContent = `Input (ส่งเข้า ONNX ตามลำดับ FEATURES)\n${JSON.stringify(data, null, 2)}\n\nOutput\n${JSON.stringify({ ...out, probability: Number(out.probability.toFixed(4)) }, null, 2)}`;
}

// แสดงชื่อโมเดล + ผลวัด 4 ตัว (5-fold CV) จาก model_meta.json
const METRIC_LABELS = { accuracy: "Accuracy", precision: "Precision", recall: "Recall", f1: "F1-Score" };
function showModelInfo(meta) {
  $("model-note").textContent = `โมเดล: ${meta.model_name} · ผลวัด 5-fold cross-validation`;
  $("metrics").innerHTML = Object.entries(METRIC_LABELS)
    .map(([key, label]) => `<div${key === "f1" ? ' class="main"' : ""}><dt>${label}</dt><dd>${meta.metrics[key].toFixed(3)}</dd></div>`)   // F1-Score เป็นตัวหลัก
    .join("");
}

function setStatus(state, text) {
  $("status").dataset.state = state;
  $("status-text").textContent = text;
}

function fillForm(values) {
  for (const name of FEATURES) $(name).value = values?.[name] ?? "";
}

// ---------- เชื่อม event ----------
$("form").addEventListener("submit", async (e) => {
  e.preventDefault();
  $("error").hidden = true;
  if (!session) {
    $("error").textContent = "โมเดลยังโหลดไม่เสร็จ";
    $("error").hidden = false;
    return;
  }
  $("submit").disabled = true;
  try {
    const data = readForm();
    showResult(data, await predict(data));
  } catch (err) {
    $("error").textContent = err.message;
    $("error").hidden = false;
  } finally {
    $("submit").disabled = false;
  }
});

document.querySelectorAll("[data-preset]").forEach((btn) =>
  btn.addEventListener("click", () => fillForm(PRESETS[btn.dataset.preset])));

// ตอนเปิดหน้า: โหลด metadata + โมเดล ONNX
(async function init() {
  fillForm(PRESETS.high);
  try {
    meta = await fetch(META_URL).then((r) => r.json());
    session = await ort.InferenceSession.create(MODEL_URL);
    setStatus("ok", "โมเดลพร้อม (รันในเบราว์เซอร์)");
    showModelInfo(meta);
  } catch (err) {
    setStatus("error", "โหลดโมเดลไม่สำเร็จ");
    $("error").textContent = `โหลด ${MODEL_URL} ไม่ได้: ${err.message} (เปิดผ่าน web server หรือยัง?)`;
    $("error").hidden = false;
  }
})();
