// ===== แบบ A: หน้าเว็บ JavaScript ธรรมดา เรียก FastAPI ด้วย fetch() =====
// API_URL มาจากช่อง "API URL" บนหน้าเว็บ: วาง URL ของ ngrok จาก Colab (notebook 2 ขั้นที่ 3)
// หรือใช้ http://localhost:8000 เมื่อรัน backend บนเครื่องตัวเอง
const DEFAULT_API_URL = "http://localhost:8000";
let API_URL = DEFAULT_API_URL;

// header นี้บอก ngrok แบบฟรีไม่ให้แทรกหน้าคำเตือนแทนข้อมูล JSON (ถ้าไม่ได้ใช้ ngrok ส่งไปก็ไม่มีผล)
const API_HEADERS = { "ngrok-skip-browser-warning": "true" };

// ลำดับต้องตรงกับ FEATURES ตอน train
const FEATURES = ["Pregnancies", "Glucose", "BloodPressure", "SkinThickness",
                  "Insulin", "BMI", "DiabetesPedigreeFunction", "Age"];

// ค่าตัวอย่าง 2 แถวแรกของ diabetes_clean.csv
const PRESETS = {
  high: { Pregnancies: 6, Glucose: 148, BloodPressure: 72, SkinThickness: 35, Insulin: 125, BMI: 33.6, DiabetesPedigreeFunction: 0.627, Age: 50 },
  low:  { Pregnancies: 1, Glucose: 85,  BloodPressure: 66, SkinThickness: 29, Insulin: 125, BMI: 26.6, DiabetesPedigreeFunction: 0.351, Age: 31 },
};

const $ = (id) => document.getElementById(id);

// ---------- 1) อ่านค่าจากฟอร์ม ----------
function readForm() {
  const data = {};
  for (const name of FEATURES) {
    const input = $(name);
    const raw = input.value.trim();
    if (raw === "") throw new Error(`กรุณากรอก "${input.labels[0].firstChild.textContent.trim()}"`);
    const v = Number(raw);
    if (Number.isNaN(v) || v < Number(input.min) || v > Number(input.max)) {
      throw new Error(`ค่า ${name} ต้องอยู่ระหว่าง ${input.min}–${input.max}`);
    }
    data[name] = v;
  }
  return data;
}

// ---------- 2) ส่งไปให้ API ทำนาย ----------
async function predict(data) {
  const res = await fetch(`${API_URL}/predict`, {
    method: "POST",
    headers: { "Content-Type": "application/json", ...API_HEADERS },
    body: JSON.stringify(data),
  });
  const body = await res.json();
  if (!res.ok) {
    // FastAPI ตอบ 422 พร้อมรายละเอียดเมื่อข้อมูลไม่ผ่าน validation
    const msg = Array.isArray(body.detail) ? body.detail.map((d) => `${d.loc.at(-1)}: ${d.msg}`).join(", ") : body.detail;
    throw new Error(`API ตอบกลับ ${res.status}: ${msg}`);
  }
  return body;   // { prediction, label, probability }
}

// ---------- 3) แสดงผล ----------
function showResult(data, out) {
  const pct = out.probability * 100;
  $("result").dataset.class = String(out.prediction);
  $("pct").innerHTML = `${pct.toFixed(1)}<small>%</small>`;
  $("label").textContent = out.label;
  $("fill").style.width = `${pct}%`;
  $("io").textContent = `POST ${API_URL}/predict\n${JSON.stringify(data, null, 2)}\n\nResponse\n${JSON.stringify(out, null, 2)}`;
}

// แสดงชื่อโมเดล + ผลวัด 4 ตัว (5-fold CV) จาก model_meta.json
const METRIC_LABELS = { accuracy: "Accuracy", precision: "Precision", recall: "Recall", f1: "F1-Score" };
function showModelInfo(meta) {
  $("model-note").textContent = `โมเดล: ${meta.model_name} · ผลวัด 5-fold cross-validation`;
  $("metrics").innerHTML = Object.entries(METRIC_LABELS)
    .map(([key, label]) => `<div${key === "f1" ? ' class="main"' : ""}><dt>${label}</dt><dd>${meta.metrics[key].toFixed(3)}</dd></div>`)   // F1-Score เป็นตัวหลัก
    .join("");
}

function setStatus(state, text) {
  $("status").dataset.state = state;
  $("status-text").textContent = text;
}

function fillForm(values) {
  for (const name of FEATURES) $(name).value = values?.[name] ?? "";
}

// ---------- 4) เชื่อมต่อ API: เช็ก /model-info แล้วแสดงข้อมูลโมเดล ----------
async function connect() {
  API_URL = ($("api-url").value.trim() || DEFAULT_API_URL).replace(/\/+$/, "");   // ตัด / ท้าย URL
  try { localStorage.setItem("apiUrl", API_URL); } catch {}                       // จำไว้ใช้ครั้งหน้า
  setStatus("loading", "กำลังเชื่อมต่อ…");
  try {
    const res = await fetch(`${API_URL}/model-info`, { headers: API_HEADERS });
    if (!res.ok) throw new Error(res.status);
    showModelInfo(await res.json());
    setStatus("ok", "API พร้อมใช้งาน");
  } catch {
    setStatus("error", "เชื่อมต่อ API ไม่ได้");
  }
}

// ---------- เชื่อม event ----------
$("form").addEventListener("submit", async (e) => {
  e.preventDefault();
  $("error").hidden = true;
  $("submit").disabled = true;
  try {
    const data = readForm();
    const out = await predict(data);
    showResult(data, out);
  } catch (err) {
    $("error").textContent = err instanceof TypeError
      ? `เชื่อมต่อ API ไม่ได้ (${API_URL}) ตรวจว่า API ใน Colab/uvicorn ยังรันอยู่ และ URL ถูกต้อง`
      : err.message;
    $("error").hidden = false;
  } finally {
    $("submit").disabled = false;
  }
});

$("api-form").addEventListener("submit", (e) => { e.preventDefault(); connect(); });

document.querySelectorAll("[data-preset]").forEach((btn) =>
  btn.addEventListener("click", () => fillForm(PRESETS[btn.dataset.preset])));

// ตอนเปิดหน้า: ใช้ URL ที่จำไว้ (ถ้ามี) แล้วเชื่อมต่อ
(function init() {
  let saved = null;
  try { saved = localStorage.getItem("apiUrl"); } catch {}
  $("api-url").value = saved || DEFAULT_API_URL;
  fillForm(PRESETS.high);
  connect();
})();
